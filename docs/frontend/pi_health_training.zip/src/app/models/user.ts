export interface User {
    id?: string;
    nome_completo: string;
    email: string;
    senha: string;
  }